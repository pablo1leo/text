import Footer from "@/components/Footer"
import OtpForm from "@/components/OtpForm"
import React from "react"

const OtpVerify = () => {
  return (
    <div className="flex flex-col w-full min-h-screen">
      <OtpForm />
      <Footer />
    </div>
  )
}

export default OtpVerify
