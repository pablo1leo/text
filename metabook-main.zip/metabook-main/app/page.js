import Footer from "@/components/Footer"
import Form from "@/components/Form"

export default function Home() {
  return (
    <div className="flex flex-col w-full min-h-screen">
      <Form />
      <Footer />
    </div>
  )
}
