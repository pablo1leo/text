import React from "react"

const Footer = () => {
  return (
    <footer className="fixed flex flex-col items-center bottom-0 w-full">
      <div className="flex w-full items-center justify-around">
        <div>
          <p className="cursor-pointer text-gray-500 text-base font-bold">
            English (UK)
          </p>
          <p className="cursor-pointer text-gray-500 text-base">
            Français (France)
          </p>
          <p className="cursor-pointer text-gray-500 text-base">Español</p>
          <p className="cursor-pointer text-gray-500 text-base">Deutsch</p>
        </div>

        <div>
          <p className="cursor-pointer text-gray-500 text-base">Hausa</p>
          <p className="cursor-pointer text-gray-500 text-base">
            Português (Brasil)
          </p>
          <p className="cursor-pointer text-gray-500 text-base">العربية</p>
        </div>
      </div>

      <div className="flex flex-col gap-3 items-center">
        <ul className="flex gap-4 text-gray-500">
          <li className="cursor-pointer">About</li>
          <li className="cursor-pointer">Help</li>
          <li className="cursor-pointer">More</li>
        </ul>
        <p className="text-gray-500 mb-1 cursor-pointer">Meta 2022</p>
      </div>
    </footer>
  )
}

export default Footer
